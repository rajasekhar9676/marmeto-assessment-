// console.log('====================================');
// console.log("Connected");
// console.log('====================================');


// 

// Get the "Add to cart" button
const addToCartBtn = document.getElementById('button');
const color1El=document.getElementById("color1")

// Add a click event listener to the button
addToCartBtn.addEventListener('click', function() {
    // Get the selected size
    const selectedSize = document.querySelector('input[name="size"]:checked').value;

    // Get the selected color
    const selectedColor = document.querySelector('.color-container div.active').style.backgroundColor;

    // Determine the color name
    let colorName;
    switch (selectedColor) {
        case 'rgb(236, 222, 204)': // yellow
            colorName = 'Yellow';
            break;
        case 'rgb(187, 210, 120)': // green
            colorName = 'Green';
            break;
        case 'rgb(187, 193, 248)': // blue
            colorName = 'Blue';
            break;
        case 'rgb(255, 211, 248)': // pink
            colorName = 'Pink';
            break;
        default:
            colorName = 'Unknown';
    }

    // Create a paragraph element to display the selected details
    const detailsParagraph = document.createElement('p');
    detailsParagraph.textContent = `Embrace Sideboard with colour ${colorName} and size ${selectedSize} is added to cart `;
    detailsParagraph.classList.add('paragraph')
    // Get the element where you want to display the selected details
    const selectedDetailsDiv = document.getElementById('selectedDetails');

    // Clear any previous details
    selectedDetailsDiv.innerHTML = '';

    // Append the details paragraph to the selected details div
    selectedDetailsDiv.appendChild(detailsParagraph);
});

// Get all color options
const colorOptions = document.querySelectorAll('.color-container div');

// Add click event listener to each color option
colorOptions.forEach(function(colorOption) {
    colorOption.addEventListener('click', function() {
        // Remove 'active' class from all color options
        colorOptions.forEach(function(option) {
            option.classList.remove('active');
        });
        // Add 'active' class to the clicked color option
        colorOption.classList.add('active');
    });
});

// Get all size radio buttons
const sizeRadios = document.querySelectorAll('input[name="size"]');

// Add click event listener to each size radio button
// sizeRadios.forEach(function(sizeRadio) {
//     sizeRadio.addEventListener('click', function() {
//         // Check if a color option is already selected
//         const selectedColor = document.querySelector('.color-container div.active');
//         if (selectedColor) {
//             // Trigger click event on "Add to cart" button
//             addToCartBtn.click();
//         }
//     });
// });



